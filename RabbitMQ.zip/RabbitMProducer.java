package com.example.demo.producer;
import com.example.demo.config.config;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;
@Component
public class RabbitMProducer {
    private final RabbitTemplate rabbitTemplate;

    public RabbitMProducer(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }
    public void sendMessage(Object message){
        rabbitTemplate.convertAndSend(config.Exchange_name,config.Routing_name,message);
    }
    public  void sendMessageWithDelay(Object message,long delayMillis){
        rabbitTemplate.convertAndSend(config.Exchange_name,config.Routing_name,message,msg ->{
            msg.getMessageProperties().setDelayLong(delayMillis);
            return msg;
        } );
    }

}
