package com.example.demo.contorller;
import com.example.demo.producer.RabbitMProducer;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

@Configuration
public class controller {
    private final RabbitMProducer rabbitMProducer;
    public  controller(RabbitMProducer rabbitMProducer){
        this.rabbitMProducer = rabbitMProducer;
    }
    @GetMapping("/send")
    public String SendMessage(@RequestParam(defaultValue = "hello")String message){
        Map<String,Object> msg= new HashMap<>();
        msg.put("content",message);
        msg.put("Timestamp",System.currentTimeMillis());
        rabbitMProducer.sendMessage(msg);
        return message;
    }
    @GetMapping("/SendDelay")
    public String senddelay(@RequestParam(defaultValue = "hello") String message,@RequestParam(defaultValue = "5000")long delay){
        Map<String,Object> msg = new HashMap<>();
        msg.put("content",message);
        msg.put("timestamp",System.currentTimeMillis());
        msg.put("delay",delay);
        rabbitMProducer.sendMessageWithDelay(msg,delay);
        return "Delayed message sent (delay: " + delay + "ms): " + message;
    }
}
