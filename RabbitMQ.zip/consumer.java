package com.example.demo.consumer;
import com.example.demo.config.config;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
@Component
public class consumer {
    @RabbitListener(queues = config.Queue_name)
    public void received(Object message){
        System.out.println(message);
    }
    @RabbitListener(queues = config.Delay_queue)
    public void delayreceived(Object message){
        System.out.println(message);
    }

}
