package com.example.demo.config;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.JacksonJsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class config {
    public static final String Exchange_name="demo_exchange";
    public static final String Queue_name="demo_queue";
    public static final String Routing_name="demo_key";
    public static final String Delay_Exchange="demo_delay_exchange";
    public static final String Delay_queue="demo_delay_queue";
    public static final String Delay_Routing="demo.delay.key";

    @Bean
    public Exchange demoexchange(){
        return ExchangeBuilder.topicExchange(Exchange_name).durable(true).build();
    }
    @Bean
    public Queue demoqueue(){
        return QueueBuilder.durable(Queue_name).build();
    }
    @Bean
    public Binding demobinding(Queue demoQueue, Exchange demoexchange){
        return BindingBuilder.bind(demoQueue).to(demoexchange).with(Routing_name).noargs();
    }
    @Bean
    public Exchange delayexchange(){
        return ExchangeBuilder.directExchange(Delay_Exchange).delayed().durable(true).build();
    }
    @Bean
    public Queue delayqueue(){
        return QueueBuilder.durable(Delay_queue).build();
    }
    @Bean
    public Binding delayBinding(){
        return BindingBuilder.bind(delayqueue()).to(delayexchange()).with(Delay_Routing).noargs();
    }
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory, JacksonJsonMessageConverter jacksonJsonMessageConverter) {
        RabbitTemplate rabbitTemplate=new RabbitTemplate(connectionFactory);
        rabbitTemplate.setMessageConverter(jacksonJsonMessageConverter);
        return rabbitTemplate;
    }
    @Bean
    public JacksonJsonMessageConverter jacksonJsonMessageConverter(){
        return new JacksonJsonMessageConverter();
    }
}
